<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Facebook;

class TestController extends Controller
{
    public function google(){



    }

    public function facebook(){

        $app_id = "1128278461236313";
        $app_secret = "3694465af9dedc5cc06499718d35734c";
        $access_token = "9ef8cd796ed3db79f843eaabf2f58171";
        $account_id = "act_143321434467456";


        $fb = new Facebook\Facebook([
            'app_id' => '757012725447864',
            'app_secret' => '0d0ad43ec38d152d660198efb8e7d154',
            'default_graph_version' => 'v2.10',
            ]);

          $helper = $fb->getRedirectLoginHelper();

          $permissions = ['email']; // Optional permissions
          $loginUrl = $helper->getLoginUrl('https://127.0.0.1:8000/api/facebook', $permissions);

          echo '<a href="' . $loginUrl . '">Log in with Facebook!</a>';
    }

}
